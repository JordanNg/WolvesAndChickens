#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

struct Riverbank {
    int chickens, wolves, boat;
};

struct State {
    struct Riverbank left;
    struct Riverbank right;

    int numSuccessors;
    //struct State* successors;
    struct State* prev;

    int depth;
    int heuristicValue;
    int pathCost;
};

struct Frontier {
    int front, rear, size;
    unsigned int capacity;
    struct State* array;  
};

struct Graph {
    struct State startState;
    struct State currentState;
    struct State goalState;

    struct Frontier queue;
    struct State* visitedArray;
    
    int visitedArraySize;
    int visitedArrayCapacity;

    int totalNodesExpanded;
};

struct Graph initializeGraph(struct State startState, struct State goalState);
struct Frontier initializeFrontier(unsigned int capacity);
int bfs(struct Graph* graph);
void expand(struct Graph* graph);
void doubleFrontier(struct Graph* graph);
void doubleVisitedArray(struct Graph* graph);
int wasExplored(struct State examine, struct Graph* graph);
int inFrontier(struct State examine, struct Graph* graph);
void prettyPrintPath(struct Graph* graph, char *outputFile);
int dfs(struct Graph* graph);
void expandReverse(struct Graph* graph);
int iddfs(struct Graph* graph, int maxDepth);
int aStar(struct Graph* graph);
int aStartHeuristic(struct Graph* graph);
int calcHeuristic(struct State state, struct State startState);

int main(int argc, char* argv[]) {
    
    // Usage checking
    if (argc != 5) {
        printf("ERROR: Incorrect usage. Proper usage is ./WolvesAndChickens <StartingState> <GoalState> <SearchMode> <OutputFile>\n");
        return -1;
    }

    FILE *fp;
    
    char startbuff[255];
    char goalbuff[255];
    char mode[15]; 
    char outputFile[100];
    strcpy(mode, argv[3]);

    int s;
    int g;

    // Initialize riverbanks for start and goal states
    int sLeftChicks, sLeftWolves, sLeftBoat;
    int sRightChicks, sRightWolves, sRightBoat;

    int gLeftChicks, gLeftWolves, gLeftBoat;
    int gRightChicks, gRightWolves, gRightBoat;

    // Using a variable to hold the start and goal file names
    // Start buffer should be 1 and goal buffer should be 2
    snprintf(startbuff, sizeof(startbuff),"%s", argv[1]);
    snprintf(goalbuff, sizeof(goalbuff),"%s", argv[2]);
    snprintf(outputFile, sizeof(outputFile),"%s", argv[4]);

    // Read the start file
    fp = fopen(startbuff, "r");
    // If unable to open the file
    if (fp == NULL) {
        printf("ERROR: Could not open filei\n");
        return -1;
    }
    // Read the file into variables
    struct State startState;
    fscanf(fp, "%d,%d,%d", &startState.left.chickens, &startState.left.wolves, &startState.left.boat);
    fscanf(fp, "%d,%d,%d", &startState.right.chickens, &startState.right.wolves, &startState.right.boat);

    fclose(fp);

    // Read goal file
    fp = fopen(goalbuff, "r");
    // If unable to open the file
    if (fp == NULL) {
        printf("ERROR: Could not open file");
        return -1;
    }
    // Read the file into variables
    struct State goalState;
    fscanf(fp, "%d,%d,%d", &goalState.left.chickens, &goalState.left.wolves, &goalState.left.boat);
    fscanf(fp, "%d,%d,%d", &goalState.right.chickens, &goalState.right.wolves, &goalState.right.boat);

    fclose(fp);

    /* ********************* PROGRAM START ********************** */

    if (strcmp(mode, "bfs") == 0) {
        printf("Executing Breadth-First-Search:\n\n\n");
        struct Graph graph = initializeGraph(startState, goalState);
        // The result of bfs will be a 0 on success and a 1 on failure
        int result = bfs(&graph);
        if (result == 0) {
            printf("BFS found a goal state after expanding %d total nodes\n", graph.totalNodesExpanded);            
        }
        prettyPrintPath(&graph, outputFile);
        fp = fopen(outputFile, "a");
        if (result == 0) {
            fprintf(fp, "BFS found a goal state after expanding %d total nodes\n", graph.totalNodesExpanded);            
        }
        fclose(fp);
    } else if (strcmp(mode, "dfs") == 0) {
        printf("Executing Depth-First-Search:\n\n\n");
        struct Graph graph = initializeGraph(startState, goalState);
        // The result of bfs will be a 0 on success and a 1 on failure
        int result = dfs(&graph);
        if (result == 0) {
            printf("DFS found a goal state after expanding %d total nodes\n", graph.totalNodesExpanded);            
        }
        prettyPrintPath(&graph, outputFile);
        fp = fopen(outputFile, "a");
        if (result == 0) {
            fprintf(fp, "DFS found a goal state after expanding %d total nodes\n", graph.totalNodesExpanded);            
        }
        fclose(fp);
    } else if (strcmp(mode, "iddfs") == 0) {
        printf("Executing Iterative-Deepening-Depth-First-Search:\n\n\n");
        struct Graph graph = initializeGraph(startState, goalState);
        int startDepth = 1;
        // The result of bfs will be a 0 on success and a 1 on failure
        int result = iddfs(&graph, startDepth); 
        if (result == 0) {
            printf("IDDFS found a goal state after expanding %d total nodes\n", graph.totalNodesExpanded);            
        }
        prettyPrintPath(&graph, outputFile);
        fp = fopen(outputFile, "a");
        if (result == 0) {
            fprintf(fp, "IDDFS found a goal state after expanding %d total nodes\n", graph.totalNodesExpanded);            
        }
        fclose(fp);
    } else if (strcmp(mode, "A*") == 0) {
        printf("Executing A* Search:\n\n\n");
        struct Graph graph = initializeGraph(startState, goalState);
        // The result of A* will be a 0 on success and a 1 on failure
        int result = aStar(&graph);
        if (result == 0) {
            printf("A* found a goal state after expanding %d total nodes\n", graph.totalNodesExpanded);            
        }
        prettyPrintPath(&graph, outputFile);
        fp = fopen(outputFile, "a");
        if (result == 0) {
            fprintf(fp, "A* found a goal state after expanding %d total nodes\n", graph.totalNodesExpanded);            
        }
        fclose(fp);
    } else {
        printf("ERROR: Incorrect Usage of Modes: <bfs>, <dfs>, <iddfs>, <A*>\n");
    }

    return 0;
}

struct Graph initializeGraph(struct State startState, struct State goalState) {
    struct Graph graph;
    graph.currentState = startState;
    graph.currentState.numSuccessors = 0;
    graph.startState = startState;
    graph.startState.numSuccessors = 0;
    graph.startState.prev = NULL;
    graph.startState.pathCost = 0;
    graph.goalState = goalState;
    graph.goalState.prev = NULL;
    graph.currentState.numSuccessors = 0;
    
    // Starting capacity of the frontier and the visited array
    unsigned int capacityInit = 10;

    //graph.currentState.successors = (struct State*) malloc(capacityInit * sizeof(struct State));
    graph.currentState.prev = NULL;

    graph.queue = initializeFrontier(capacityInit);
    graph.visitedArray = (struct State*) malloc(capacityInit * sizeof(struct State));
    graph.visitedArraySize = 0;
    graph.visitedArrayCapacity = capacityInit;

    graph.totalNodesExpanded = 0;

    return graph;
}

struct Frontier initializeFrontier(unsigned int capacity){
    struct Frontier frontier;
    frontier.front = 0;
    frontier.rear = 0;
    frontier.size = 0;
    frontier.capacity = capacity;
    frontier.array = (struct State*) malloc(capacity * sizeof(struct State));
    return frontier;
}

// Breadth-First-Search
int bfs(struct Graph* graph) {
    // Put the first item into the frontier
    graph->queue.array[0] = graph->startState;
    graph->queue.rear++;
    graph->queue.size++;

    int i = 0;

    int nodesExpanded = 0;

    do {
        // If FRONTIER is empty then return failure
        if (graph->queue.size == 0) {
            printf("BFS was unable to find a path to the solution\n");
            return 1;
        }
        // choose the first node in frontier and remove it
        graph->currentState = graph->queue.array[i];
        graph->queue.front++; // Increment the front of the queue

        // check if the node is a goal state
        if (!isGoalState(graph->currentState, graph->goalState)) {
            //printf("BFS found a goal state after expanding %d nodes\n", nodesExpanded);           
            return 0;
        }

        // Check to make sure the visited array has space for another item
        if (graph->visitedArraySize + 1 >= graph->visitedArrayCapacity) {
            doubleVisitedArray(graph);
        }
        // add the node to the visited array
        graph->visitedArray[i] = graph->queue.array[i];
        graph->visitedArraySize++;

        // Check if there is enough space in the frontier for more successors
        if (graph->queue.rear + 5 >= graph->queue.capacity) {
            // Attmept to allocate more space for the frontier
            doubleFrontier(graph);
        }
        // generate successors for the node
        // adding them to the frontier if not already in the frontier or explored set
        graph->totalNodesExpanded++;
        expand(graph);
        int j = 0;
        /*printf("\tFrontier after %d expansion:\n", i);
        for (j = graph->queue.front; j < graph->queue.size; j++) {
            printf("\tENTRY: %d\n", j);
            printf("\tL: %d %d %d\n", graph->queue.array[j].left.chickens, graph->queue.array[j].left.wolves, graph->queue.array[j].left.boat);
            printf("\tR: %d %d %d\n", graph->queue.array[j].right.chickens, graph->queue.array[j].right.wolves, graph->queue.array[j].right.boat);
        }
        printf("\n");*/
        i++;
    } while (1);
}

int dfs(struct Graph* graph) {
    // Put the first item into the frontier
    graph->queue.array[0] = graph->startState;
    graph->queue.rear++;
    graph->queue.size++;

    int i = 0;
    int k =0;
    
    int nodesExpanded = 0;

    do {
        // If FRONTIER is empty then return failure
        if (graph->queue.size == 0) {
            printf("DFS was unable to find a path to the solution\n");
            return 1;
        }

        // choose the last node in frontier and remove it
        graph->currentState = graph->queue.array[graph->queue.rear - 1];
        graph->queue.rear--;
        graph->queue.size--;

        // check if the node is a goal state
        if (!isGoalState(graph->currentState, graph->goalState)) {
            //printf("DFS found a goal state after expanding %d nodes\n", nodesExpanded);           
            return 0;
        }

        // Check to make sure the visited array has space for another item
        if (graph->visitedArraySize + 1 >= graph->visitedArrayCapacity) {
            doubleVisitedArray(graph);
        }
        // add the node to the visited array
        graph->visitedArray[i] = graph->currentState;
        graph->visitedArraySize++;

        // Check if there is enough space in the frontier for more successors
        if (graph->queue.rear + 5 >= graph->queue.capacity) {
            // Attmept to allocate more space for the frontier
            doubleFrontier(graph);
        }
        // generate successors for the node
        // adding them to the frontier if not already in the frontier or explored set
        graph->totalNodesExpanded++;
        expandReverse(graph);
        /*int j = 0;
        printf("\tFrontier after %d expansion:\n", i);
        for (j = graph->queue.front; j < graph->queue.size; j++) {
            printf("\tENTRY: %d\n", j);
            printf("\tL: %d %d %d\n", graph->queue.array[j].left.chickens, graph->queue.array[j].left.wolves, graph->queue.array[j].left.boat);
            printf("\tR: %d %d %d\n", graph->queue.array[j].right.chickens, graph->queue.array[j].right.wolves, graph->queue.array[j].right.boat);
        }
        printf("\n");*/
        i++;
    } while (1);
}

int iddfs(struct Graph* graph, int maxDepth) {
    // Put the first item into the frontier
    graph->startState.depth = 0;
    graph->queue.array[0] = graph->startState;
    graph->queue.rear++;
    graph->queue.size++;

    int i = 0;
    int k =0;

    int currentDepth = 0;
    int nodesExpanded = 0;

    do {
        // If FRONTIER is empty then return failure
        if (graph->queue.size == 0) {
            // Reset our thingys
            printf("IDDFS was unable to find a path to the solution with a max depth of %d\n", maxDepth);
            graph->queue.front = 0;
            graph->queue.rear = 0;
            graph->queue.size = 0;

            graph->visitedArraySize = 0;
            graph->currentState = graph->startState;

            printf("Trying again with an increased max depth\n\n");
            iddfs(graph, maxDepth + 1);
            return iddfs(graph, maxDepth + 1);
        }

        // choose the last node in frontier and remove it
        graph->currentState = graph->queue.array[graph->queue.rear - 1];
        graph->queue.rear--;
        graph->queue.size--;

        // check if the node is a goal state
        if (!isGoalState(graph->currentState, graph->goalState)) {
            //printf("IDDFS found a goal state after expanding %d nodes\n", nodesExpanded);           
            return 0;
        }

        // Check to make sure the visited array has space for another item
        if (graph->visitedArraySize + 1 >= graph->visitedArrayCapacity) {
            doubleVisitedArray(graph);
        }
        // add the node to the visited array
        graph->visitedArray[i] = graph->currentState;
        graph->visitedArraySize++;

        // Check if there is enough space in the frontier for more successors
        if (graph->queue.rear + 5 >= graph->queue.capacity) {
            // Attmept to allocate more space for the frontier
            doubleFrontier(graph);
        }
        // generate successors for the node
        // adding them to the frontier if not already in the frontier or explored set
        graph->totalNodesExpanded++;

        if (graph->currentState.depth != maxDepth) {
            expandReverse(graph);
        }
        /*int j = 0;
        printf("\tFrontier after %d action:\n", i);
        for (j = graph->queue.front; j < graph->queue.size; j++) {
            printf("\tENTRY: %d\n", j);
            printf("\tL: %d %d %d\n", graph->queue.array[j].left.chickens, graph->queue.array[j].left.wolves, graph->queue.array[j].left.boat);
            printf("\tR: %d %d %d\n", graph->queue.array[j].right.chickens, graph->queue.array[j].right.wolves, graph->queue.array[j].right.boat);
        }
        printf("\n");*/
        i++;
    } while (1);
}

// A* search function
// returns 0 on success and 1 on failure
int aStar(struct Graph* graph) {
    // Put the first item into the frontier
    graph->queue.array[0] = graph->startState;
    graph->queue.rear++;
    graph->queue.size++;

    int i = 0;
    int totalNodesExpanded = 0;

    int k = 0;
    do {
        // If FRONTIER is empty then return failure
        if (graph->queue.size == 0) {
            printf("A* was unable to find a path to the solution\n");
            return 1;
        }

        // Find the node in the frontier with the lowest path cost + h(n)
        int n = 0;
        int currentLowest = 0;
        int currentLowestPosition = 0;
        for(n = graph->queue.front; n < graph->queue.rear; n++) {
            if (currentLowest > graph->queue.array[n].pathCost + calcHeuristic(graph->queue.array[n], graph->startState)) {
                currentLowest =  graph->queue.array[n].pathCost + calcHeuristic(graph->queue.array[n], graph->startState);
                currentLowestPosition = n;
            }
        }

        // After finding the lowest f(n) we would have to remove it from the array and then reorder the array
        graph->currentState = graph->queue.array[currentLowestPosition];
        // Reorder Array
        for(n = currentLowestPosition; n < graph->queue.size; n++) {
            graph->queue.array[n] = graph->queue.array[n + 1];
        }
        // Bookkeep
        graph->queue.rear--;
        graph->queue.size--;

        // check if the node is a goal state
        if (!isGoalState(graph->currentState, graph->goalState)) {
            return 0;
        }

        // Check to make sure the visited array has space for another item
        if (graph->visitedArraySize + 1 >= graph->visitedArrayCapacity) {
            doubleVisitedArray(graph);
        }
        // add the node to the visited array
        graph->visitedArray[i] = graph->currentState;
        graph->visitedArraySize++;

        // Check if there is enough space in the frontier for more successors
        if (graph->queue.rear + 5 >= graph->queue.capacity) {
            // Attmept to allocate more space for the frontier
            doubleFrontier(graph);
        }
        // generate successors for the node
        // adding them to the frontier if not already in the frontier or explored set
        graph->totalNodesExpanded++;
        expand(graph);
        /*int j = 0;
        printf("\tFrontier after %d expansion:\n", i);
        for (j = graph->queue.front; j < graph->queue.size; j++) {
            printf("\tENTRY: %d\n", j);
            printf("\tL: %d %d %d\n", graph->queue.array[j].left.chickens, graph->queue.array[j].left.wolves, graph->queue.array[j].left.boat);
            printf("\tR: %d %d %d\n", graph->queue.array[j].right.chickens, graph->queue.array[j].right.wolves, graph->queue.array[j].right.boat);
        }
        printf("\n");*/
        i++;
    } while(1);
}

int calcHeuristic(struct State state, struct State startState) {
    
    int numAnimalsLeftToMove = 0;
    int heuristicCost = 0;
    // Based on the side the boat is currently on, we can compute our heuristic
    if (state.left.boat == 1) { // If the boat is currently on the left
        if (startState.left.boat == 1) { // If the boat started on the left
            numAnimalsLeftToMove = state.left.chickens + state.left.wolves;

            // Based on the number of animals left to move we can underestimate the cost to reach the goal
            // We could say that at a minimum when relaxing the problem's rules of wolves eating chickens,
            // It would take a minimum of pairs of animals * 2 - 1 trips to get all the animals to the other side
            heuristicCost = ceil((double) numAnimalsLeftToMove / (double) 2) - 1;
            return heuristicCost;
        } else { // The boat is on the goal side
            numAnimalsLeftToMove = state.right.chickens + state.right.wolves;

            // The same could be said as above if we took one more trip to move the boat back 
            heuristicCost = ceil((double) numAnimalsLeftToMove / (double) 2) - 1;
            // If the boat is on the goal side and there are no animals left on the other side, then 0/2 - 1 = -1 and
            // adding 1 results in a cost of 0 for a goal state
            return heuristicCost + 1;
        }
    } else { // The boat is currently on the right
        if (startState.right.boat == 1) { // The boat is on the start side
            numAnimalsLeftToMove = state.right.chickens + state.right.wolves;
            // Based on the number of animals left to move we can underestimate the cost to reach the goal
            // We could say that at a minimum when relaxing the problem's rules of wolves eating chickens,
            // It would take a minimum of pairs of animals * 2 - 1 trips to get all the animals to the other side
            heuristicCost = ceil((double) numAnimalsLeftToMove / (double) 2) - 1;
            return heuristicCost;
        } else { // The boat is on the goal side
            numAnimalsLeftToMove = state.left.chickens + state.left.wolves;
            // The same could be said as above if we took one more trip to move the boat back 
            heuristicCost = ceil((double) numAnimalsLeftToMove / (double) 2) - 1;
            return heuristicCost + 1;
        }
    }

}

void doubleFrontier(struct Graph* graph) {
    // Increase the capacity of the frontier twice the current capacity
    graph->queue.capacity = 2 * graph->queue.capacity;
    // Attempt to realloc memory
    graph->queue.array = (struct State*) realloc(graph->queue.array, graph->queue.capacity * sizeof(struct State));
}

void doubleVisitedArray(struct Graph* graph) {
    // Double the capacity of the visited array
    graph->visitedArrayCapacity = 2 * graph->visitedArrayCapacity;
    // Attempt to realloc memory
    graph->visitedArray = (struct State*) realloc(graph->visitedArray, graph->visitedArrayCapacity * sizeof(struct State));
}


// Checks if the current state is a goal state, returns 1 on failure and 0 on success
int isGoalState(struct State node, struct State goalState) {
    if (node.left.chickens == goalState.left.chickens && node.left.wolves == goalState.left.wolves && node.left.boat == goalState.left.boat)
        if (node.right.chickens == goalState.right.chickens && node.right.wolves == goalState.right.wolves && node.right.boat == goalState.right.boat)
            return 0;
    return 1;
}

// Helper function to check if node is in visited array
// Returns 1 on failure and 0 on success
int wasExplored(struct State examine, struct Graph* graph) {
    int i = 0;
    // Check each item in the explored set
    for (i = 0; i < graph->visitedArraySize; i++) {
        if (graph->visitedArray[i].left.chickens == examine.left.chickens && graph->visitedArray[i].left.wolves == examine.left.wolves 
            && graph->visitedArray[i].left.boat == examine.left.boat) {
            if (graph->visitedArray[i].right.chickens == examine.right.chickens && graph->visitedArray[i].right.wolves == examine.right.wolves 
                && graph->visitedArray[i].right.boat == examine.right.boat) {
                return 0;
            }
        }
    }

    return 1;
}

// Helper function to check if node is in the frontier
// Returns 1 on failure and 0 on success
int inFrontier(struct State examine, struct Graph* graph) {
    int i = 0;
    // Check each item in the explored set
    for (i = graph->queue.front; i < graph->queue.size; i++) {
        if (graph->queue.array[i].left.chickens == examine.left.chickens && graph->queue.array[i].left.wolves == examine.left.wolves 
            && graph->queue.array[i].left.boat == examine.left.boat) {
            if (graph->queue.array[i].right.chickens == examine.right.chickens && graph->queue.array[i].right.wolves == examine.right.wolves 
                && graph->queue.array[i].right.boat == examine.right.boat) {
                return 0;
            }
        }
    }

    return 1;
}

void prettyPrintPath(struct Graph* graph, char *outputFile) {

    FILE *fp;
    int i = 0;
    fp = fopen(outputFile, "w");
    while(graph->currentState.prev != NULL) {
        fprintf(fp, "Left Riverbank: \tchickens: %d, \twolves: %d, \tboat: %d\n", graph->currentState.left.chickens, graph->currentState.left.wolves, graph->currentState.left.boat);
        fprintf(fp, "Right Riverbank: \tchickens: %d, \twolves: %d, \tboat: %d\n", graph->currentState.right.chickens, graph->currentState.right.wolves, graph->currentState.right.boat);
        fprintf(fp, "\n");
        printf("Left Riverbank: \tchickens: %d, \twolves: %d, \tboat: %d\n", graph->currentState.left.chickens, graph->currentState.left.wolves, graph->currentState.left.boat);
        printf("Right Riverbank: \tchickens: %d, \twolves: %d, \tboat: %d\n", graph->currentState.right.chickens, graph->currentState.right.wolves, graph->currentState.right.boat);
        printf("\n");
        i++;
        // REMEMBER TO FREE
        graph->currentState = *graph->currentState.prev;
    }
    
    // Print the start state
    fprintf(fp, "Left Riverbank: \tchickens: %d, \twolves: %d, \tboat: %d\n", graph->startState.left.chickens, graph->startState.left.wolves, graph->startState.left.boat);
    fprintf(fp, "Right Riverbank: \tchickens: %d, \twolves: %d, \tboat: %d\n", graph->startState.right.chickens, graph->startState.right.wolves, graph->startState.right.boat);
    printf("Left Riverbank: \tchickens: %d, \twolves: %d, \tboat: %d\n", graph->startState.left.chickens, graph->startState.left.wolves, graph->startState.left.boat);
    printf("Right Riverbank: \tchickens: %d, \twolves: %d, \tboat: %d\n", graph->startState.right.chickens, graph->startState.right.wolves, graph->startState.right.boat);
    i++;

    fprintf(fp, "Number of nodes on solution path: %d\n", i);
    printf("Number of nodes on solution path: %d\n", i);
    fclose(fp);
}

void expand(struct Graph* graph) {

    int boatOnLeft = 0;
    // Determine where the boat is 
    if (graph->currentState.left.boat == 1)
        boatOnLeft = 1;
    else 
        boatOnLeft = 0;

    int i = 0;
    // Required order of generation
    if (boatOnLeft) {
        // Put one chicken in the boat
        if (graph->currentState.left.chickens != 0 ) {
            if (graph->currentState.left.chickens - 1 >= graph->currentState.left.wolves || graph->currentState.left.wolves == 0 || graph->currentState.left.chickens - 1 == 0) {
                if (graph->currentState.right.chickens + 1 >= graph->currentState.right.wolves || graph->currentState.right.wolves == 0) {
                    // Add new state to the array
                    struct State new = graph->currentState;
                    struct State *holdState = (struct State*) malloc(sizeof(struct State));
                    // Allocate 5 struct States for new's successors
                    //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                    new.prev = NULL;

                    new.left.chickens -= 1;
                    new.right.chickens += 1;
                    new.left.boat = 0;
                    new.right.boat = 1;
                    new.pathCost++;
 
                    *holdState = graph->currentState;

                    // If the new node was not explored and is not in the frontier then add it
                    if (wasExplored(new, graph) && inFrontier(new, graph)) {
                        // Point new to the parent node
                        new.prev = holdState;               
                        //new.prev = &graph->currentState;               
                
                        // Add new to the parent node's successor array
                        //graph->currentState.successors[i] = new;
                        i++;
                        graph->currentState.numSuccessors++;

                        // Slap onto back of frontier
                        graph->queue.array[graph->queue.rear] = new;
                        graph->queue.rear++;
                        graph->queue.size++;
                    } else {
                        //free(new.successors);
                    }
                }
            }
        }
        // Put two chickens in the boat
        if (graph->currentState.left.chickens >= 2) {
            if (graph->currentState.left.chickens - 2 >= graph->currentState.left.wolves || graph->currentState.left.wolves == 0 || graph->currentState.left.chickens - 2 == 0) {
                if (graph->currentState.right.chickens + 2 >= graph->currentState.right.wolves || graph->currentState.right.wolves == 0) {
                    // Add to the array
                    struct State new = graph->currentState;
                    struct State *holdState = (struct State*) malloc(sizeof(struct State));
                    // Allocate 5 struct States for new's successors
                    //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                    new.prev = NULL;

                    new.left.chickens -= 2;
                    new.right.chickens += 2;
                    new.left.boat = 0;
                    new.right.boat = 1;
                    new.pathCost++;
                
                    *holdState = graph->currentState;

                    // If the new node was not explored then add it
                    if (wasExplored(new, graph) && inFrontier(new, graph)) {
                        // Point new to the parent node
                        new.prev = holdState;               
                        //new.prev = &graph->currentState;               
                
                        // Add new to the parent node's successor array
                        //graph->currentState.successors[i] = new;
                        i++;
                        graph->currentState.numSuccessors++;

                        // Slap onto back of frontier
                        graph->queue.array[graph->queue.rear] = new;
                        graph->queue.rear++;
                        graph->queue.size++;
                    } else {
                        //free(new.successors);
                    }
                }
            }
        }
        // Put one wolf in the boat
        if (graph->currentState.left.wolves != 0) {
            if (graph->currentState.right.chickens >= graph->currentState.right.wolves + 1 || graph->currentState.right.chickens == 0) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.left.wolves -= 1;
                new.right.wolves += 1;
                new.left.boat = 0;
                new.right.boat = 1;
                new.pathCost++;
         
                *holdState = graph->currentState;

                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new, graph)) {
                    // Point new to the parent node
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new;
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
        // Put one wolf and one chicken in the boat
        if (graph->currentState.left.chickens != 0 && graph->currentState.left.wolves != 0) {
            if (!(graph->currentState.right.wolves > graph->currentState.right.chickens)) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.left.chickens -= 1;
                new.right.chickens += 1;
                new.left.wolves -= 1;
                new.right.wolves += 1;
                new.left.boat = 0;
                new.right.boat = 1;
                new.pathCost++;
                
                *holdState = graph->currentState;

                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new, graph)) {
                    // Point new to the parent node
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new;
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
        // Put two wolves in the boat
        if (graph->currentState.left.wolves >= 2) {
            if (graph->currentState.right.chickens >= graph->currentState.right.wolves + 2 || graph->currentState.right.chickens == 0) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.left.wolves -= 2;
                new.right.wolves += 2;
                new.left.boat = 0;
                new.right.boat = 1;
                new.pathCost++;

                *holdState = graph->currentState;
               
                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new,graph)) {
                    // Point new to the parent node
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new;
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
    } else { 
        // Put one chicken in the boat
        if (graph->currentState.right.chickens != 0 ) {
            if (graph->currentState.right.chickens - 1 >= graph->currentState.right.wolves || graph->currentState.right.wolves == 0 || graph->currentState.right.chickens - 1 == 0) {
                if (graph->currentState.left.chickens + 1 >= graph->currentState.left.wolves || graph->currentState.left.wolves == 0) {
                    // Add new state to the array
                    struct State new = graph->currentState;
                    struct State *holdState = (struct State*) malloc(sizeof(struct State));
                    // Allocate 5 struct States for new's successors
                    //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                    new.prev = NULL;

                    new.right.chickens -= 1;
                    new.left.chickens += 1;
                    new.right.boat = 0;
                    new.left.boat = 1;
                    new.pathCost++;
                    
                    *holdState = graph->currentState;
                
                    // If the new node was not explored then add it
                    if (wasExplored(new, graph) && inFrontier(new, graph)) {
                        // Point new to the parent node
                        new.prev = holdState;               
                        //new.prev = &graph->currentState;               
                
                        // Add new to the parent node's successor array
                        //graph->currentState.successors[i] = new;
                        i++;
                        graph->currentState.numSuccessors++;

                        // Slap onto back of frontier
                        graph->queue.array[graph->queue.rear] = new;
                        graph->queue.rear++;
                        graph->queue.size++;
                    } else {
                        //free(new.successors);
                    }
                }
            }
        }
        // Put two chickens in the boat
        if (graph->currentState.right.chickens >= 2) {
            if (graph->currentState.right.chickens - 2 >= graph->currentState.right.wolves || graph->currentState.right.wolves == 0 || graph->currentState.right.chickens - 2 == 0) {
                if (graph->currentState.left.chickens + 2 >= graph->currentState.left.wolves || graph->currentState.left.wolves == 0) {
                    // Add to the array
                    struct State new = graph->currentState;
                    struct State *holdState = (struct State*) malloc(sizeof(struct State));
                    // Allocate 5 struct States for new's successors
                    //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                    new.prev = NULL;

                    new.right.chickens -= 2;
                    new.left.chickens += 2;
                    new.right.boat = 0;
                    new.left.boat = 1;
                    new.pathCost++;

                    *holdState = graph->currentState;
                
                    // If the new node was not explored then add it
                    if (wasExplored(new, graph) && inFrontier(new, graph)) {
                        // Point new to the parent node
                        new.prev = holdState;               
                        //new.prev = &graph->currentState;               
                
                        // Add new to the parent node's successor array
                        //graph->currentState.successors[i] = new;
                        i++;
                        graph->currentState.numSuccessors++;

                        // Slap onto back of frontier
                        graph->queue.array[graph->queue.rear] = new;
                        graph->queue.rear++;
                        graph->queue.size++;
                    } else {
                        //free(new.successors);
                    }
                }
            }
        }
        // Put one wolf in the boat
        if (graph->currentState.right.wolves != 0) {
            if (graph->currentState.left.chickens >= graph->currentState.left.wolves + 1 || graph->currentState.left.chickens == 0) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));

                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.right.wolves -= 1;
                new.left.wolves += 1;
                new.right.boat = 0;
                new.left.boat = 1;
                new.pathCost++;

                *holdState = graph->currentState;
                
                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new, graph)) {
                    // Point new to the current node having successors generated
                    //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new; // Prev works here
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
        // Put one wolf and one chicken in the boat
        if (graph->currentState.right.chickens != 0 && graph->currentState.right.wolves != 0) {
            if (!(graph->currentState.left.wolves > graph->currentState.left.chickens)) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.right.chickens -= 1;
                new.left.chickens += 1;
                new.right.wolves -= 1;
                new.left.wolves += 1;
                new.right.boat = 0;
                new.left.boat = 1;
                new.pathCost++;
                
                *holdState = graph->currentState;

                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new, graph)) {
                    // Point new to the parent node
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new;
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
        // Put two wolves in the boat
        if (graph->currentState.right.wolves >= 2) {
            if (graph->currentState.left.chickens >= graph->currentState.left.wolves + 2 || graph->currentState.left.chickens == 0) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.right.wolves -= 2;
                new.left.wolves += 2;
                new.right.boat = 0;
                new.left.boat = 1;
                new.pathCost++;
                
                *holdState = graph->currentState;

                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new, graph)) {
                    // Point new to the parent node
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new;
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
    }
}


void expandReverse(struct Graph* graph) {

    int boatOnLeft = 0;
    // Determine where the boat is 
    if (graph->currentState.left.boat == 1)
        boatOnLeft = 1;
    else 
        boatOnLeft = 0;

    int i = 0;
    // Required order of generation in reverse
    if (boatOnLeft) {
        // Put two wolves in the boat
        if (graph->currentState.left.wolves >= 2) {
            if (graph->currentState.right.chickens >= graph->currentState.right.wolves + 2 || graph->currentState.right.chickens == 0) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.left.wolves -= 2;
                new.right.wolves += 2;
                new.left.boat = 0;
                new.right.boat = 1;
                new.depth++;
               
                *holdState = graph->currentState;

                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new,graph)) {
                    // Point new to the parent node
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new;
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
        // Put one wolf and one chicken in the boat
        if (graph->currentState.left.chickens != 0 && graph->currentState.left.wolves != 0) {
            if (!(graph->currentState.right.wolves > graph->currentState.right.chickens)) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.left.chickens -= 1;
                new.right.chickens += 1;
                new.left.wolves -= 1;
                new.right.wolves += 1;
                new.left.boat = 0;
                new.right.boat = 1;
                new.depth++;
                
                *holdState = graph->currentState;

                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new, graph)) {
                    // Point new to the parent node
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new;
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
        // Put one wolf in the boat
        if (graph->currentState.left.wolves != 0) {
            if (graph->currentState.right.chickens >= graph->currentState.right.wolves + 1 || graph->currentState.right.chickens == 0) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.left.wolves -= 1;
                new.right.wolves += 1;
                new.left.boat = 0;
                new.right.boat = 1;
                new.depth++;
         
                *holdState = graph->currentState;

                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new, graph)) {
                    // Point new to the parent node
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new;
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
        // Put two chickens in the boat
        if (graph->currentState.left.chickens >= 2) {
            if (graph->currentState.left.chickens - 2 >= graph->currentState.left.wolves || graph->currentState.left.wolves == 0 || graph->currentState.left.chickens - 2 == 0) {
                if (graph->currentState.right.chickens + 2 >= graph->currentState.right.wolves || graph->currentState.right.wolves == 0) {
                    // Add to the array
                    struct State new = graph->currentState;
                    struct State *holdState = (struct State*) malloc(sizeof(struct State));
                    // Allocate 5 struct States for new's successors
                    //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                    new.prev = NULL;

                    new.left.chickens -= 2;
                    new.right.chickens += 2;
                    new.left.boat = 0;
                    new.right.boat = 1;
                    new.depth++;
                
                    *holdState = graph->currentState;

                    // If the new node was not explored then add it
                    if (wasExplored(new, graph) && inFrontier(new, graph)) {
                        // Point new to the parent node
                        new.prev = holdState;               
                        //new.prev = &graph->currentState;               
                
                        // Add new to the parent node's successor array
                        //graph->currentState.successors[i] = new;
                        i++;
                        graph->currentState.numSuccessors++;

                        // Slap onto back of frontier
                        graph->queue.array[graph->queue.rear] = new;
                        graph->queue.rear++;
                        graph->queue.size++;
                    } else {
                        //free(new.successors);
                    }
                }
            }
        }
        // Put one chicken in the boat
        if (graph->currentState.left.chickens != 0 ) {
            if (graph->currentState.left.chickens - 1 >= graph->currentState.left.wolves || graph->currentState.left.wolves == 0 || graph->currentState.left.chickens - 1 == 0) {
                if (graph->currentState.right.chickens + 1 >= graph->currentState.right.wolves || graph->currentState.right.wolves == 0) {
                    // Add new state to the array
                    struct State new = graph->currentState;
                    struct State *holdState = (struct State*) malloc(sizeof(struct State));
                    // Allocate 5 struct States for new's successors
                    //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                    new.prev = NULL;

                    new.left.chickens -= 1;
                    new.right.chickens += 1;
                    new.left.boat = 0;
                    new.right.boat = 1;
                    new.depth++;
 
                    *holdState = graph->currentState;

                    // If the new node was not explored and is not in the frontier then add it
                    if (wasExplored(new, graph) && inFrontier(new, graph)) {
                        // Point new to the parent node
                        new.prev = holdState;               
                        //new.prev = &graph->currentState;               
                
                        // Add new to the parent node's successor array
                        //graph->currentState.successors[i] = new;
                        i++;
                        graph->currentState.numSuccessors++;

                        // Slap onto back of frontier
                        graph->queue.array[graph->queue.rear] = new;
                        graph->queue.rear++;
                        graph->queue.size++;
                    } else {
                        //free(new.successors);
                    }
                }
            }
        }
    } else { 
        // Put two wolves in the boat
        if (graph->currentState.right.wolves >= 2) {
            if (graph->currentState.left.chickens >= graph->currentState.left.wolves + 2 || graph->currentState.left.chickens == 0) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.right.wolves -= 2;
                new.left.wolves += 2;
                new.right.boat = 0;
                new.left.boat = 1;
                new.depth++;
                
                *holdState = graph->currentState;

                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new, graph)) {
                    // Point new to the parent node
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new;
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
        // Put one wolf and one chicken in the boat
        if (graph->currentState.right.chickens != 0 && graph->currentState.right.wolves != 0) {
            if (!(graph->currentState.left.wolves > graph->currentState.left.chickens)) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.right.chickens -= 1;
                new.left.chickens += 1;
                new.right.wolves -= 1;
                new.left.wolves += 1;
                new.right.boat = 0;
                new.left.boat = 1;
                new.depth++;
                
                *holdState = graph->currentState;

                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new, graph)) {
                    // Point new to the parent node
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new;
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
        // Put one wolf in the boat
        if (graph->currentState.right.wolves != 0) {
            if (graph->currentState.left.chickens >= graph->currentState.left.wolves + 1 || graph->currentState.left.chickens == 0) {
                // Add to the array
                struct State new = graph->currentState;
                struct State *holdState = (struct State*) malloc(sizeof(struct State));
                // Allocate 5 struct States for new's successors
                //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                new.prev = NULL;

                new.right.wolves -= 1;
                new.left.wolves += 1;
                new.right.boat = 0;
                new.left.boat = 1;
                new.depth++;
                
                *holdState = graph->currentState;

                // If the new node was not explored then add it
                if (wasExplored(new, graph) && inFrontier(new, graph)) {
                    // Point new to the current node having successors generated
                    //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                    new.prev = holdState;               
                    //new.prev = &graph->currentState;               
                
                    // Add new to the parent node's successor array
                    //graph->currentState.successors[i] = new;
                    i++;
                    graph->currentState.numSuccessors++;

                    // Slap onto back of frontier
                    graph->queue.array[graph->queue.rear] = new; // Prev works here
                    graph->queue.rear++;
                    graph->queue.size++;
                } else {
                    //free(new.successors);
                }
            }
        }
        // Put two chickens in the boat
        if (graph->currentState.right.chickens >= 2) {
            if (graph->currentState.right.chickens - 2 >= graph->currentState.right.wolves || graph->currentState.right.wolves == 0 || graph->currentState.right.chickens - 2 == 0) {
                if (graph->currentState.left.chickens + 2 >= graph->currentState.left.wolves || graph->currentState.left.wolves == 0) {
                    // Add to the array
                    struct State new = graph->currentState;
                    struct State *holdState = (struct State*) malloc(sizeof(struct State));
                    // Allocate 5 struct States for new's successors
                    //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                    new.prev = NULL;

                    new.right.chickens -= 2;
                    new.left.chickens += 2;
                    new.right.boat = 0;
                    new.left.boat = 1;
                    new.depth++;
                
                    *holdState = graph->currentState;

                    // If the new node was not explored then add it
                    if (wasExplored(new, graph) && inFrontier(new, graph)) {
                        // Point new to the parent node
                        new.prev = holdState;               
                        //new.prev = &graph->currentState;               
                
                        // Add new to the parent node's successor array
                        //graph->currentState.successors[i] = new;
                        i++;
                        graph->currentState.numSuccessors++;

                        // Slap onto back of frontier
                        graph->queue.array[graph->queue.rear] = new;
                        graph->queue.rear++;
                        graph->queue.size++;
                    } else {
                        //free(new.successors);
                    }
                }
            }
        }
        // Put one chicken in the boat
        if (graph->currentState.right.chickens != 0 ) {
            if (graph->currentState.right.chickens - 1 >= graph->currentState.right.wolves || graph->currentState.right.wolves == 0 || graph->currentState.right.chickens - 1 == 0) {
                if (graph->currentState.left.chickens + 1 >= graph->currentState.left.wolves || graph->currentState.left.wolves == 0) {
                    // Add new state to the array
                    struct State new = graph->currentState;
                    struct State *holdState = (struct State*) malloc(sizeof(struct State));
                    // Allocate 5 struct States for new's successors
                    //new.successors = (struct State*) malloc(5 * sizeof(struct State));
                    new.prev = NULL;

                    new.right.chickens -= 1;
                    new.left.chickens += 1;
                    new.right.boat = 0;
                    new.left.boat = 1;
                    new.depth++;
                
                    *holdState = graph->currentState;

                    // If the new node was not explored then add it
                    if (wasExplored(new, graph) && inFrontier(new, graph)) {
                        // Point new to the parent node
                        new.prev = holdState;               
                        //new.prev = &graph->currentState;               
                
                        // Add new to the parent node's successor array
                        //graph->currentState.successors[i] = new;
                        i++;
                        graph->currentState.numSuccessors++;

                        // Slap onto back of frontier
                        graph->queue.array[graph->queue.rear] = new;
                        graph->queue.rear++;
                        graph->queue.size++;
                    } else {
                        //free(new.successors);
                    }
                }
            }
        }
    }
}

