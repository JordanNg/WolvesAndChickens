Hello grader!
In order to compile my code please use the command:

    gcc -o wcRebuild wcRebuild.c -lm

In order to run my code here is a list of the commands that are viable:
    
    ./wcRebuild <start_file> <goal_file> <mode> <output_file>

Here is a list of modes for you to use:
    
    bfs
    dfs
    iddfs
    A*

That should be all that you need to run and execute my code, if you have questions
please feel free to email me at ngjor@oregonstate.edu
